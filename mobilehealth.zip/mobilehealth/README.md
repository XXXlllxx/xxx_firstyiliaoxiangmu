# healthcare
基于Android Studio的一个医疗系统，安卓期末大作业...
主要有以下几个模块：
- Login and Register
- Home
- Lab Test
- Buy Medicine
- Find Doctor
- HealthArticles
- Order Details
- Logout

主要使用了ListView、Intent、Activity、SQLite技术
